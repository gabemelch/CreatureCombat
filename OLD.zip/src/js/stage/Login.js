
    // Import the necessary dependencies
    import { MongoClient } from 'mongodb';
    import * as me from 'melonjs';
import { tSMethodSignature } from '../../../../../../../AppData/Local/Microsoft/TypeScript/4.9/node_modules/@babel/types/lib/index';

    // Connect to the MongoDB database
    const client = new MongoClient('mongodb://localhost:27017', { useUnifiedTopology: true });
    client.connect((err) => {
      if (err) {
        console.error('Error connecting to MongoDB', err);
        return;
      }
      console.log('Connected to MongoDB');
      //Load images for buttons using preloader
      me.loader.preload({
        name: 'LoginButton',
        type: 'image',
        src: '../../img/LogIn.png'
      });
      me.loader.preload({
        name: 'SignUpButton',
        type: 'image',
        src: '../../img.Signup.png'
      });
      // Define the login screen entity
      const LoginScreen = me.ScreenObject.extend({
        // Initialize the screen
        init: function() {
          this._super(me.ScreenObject, 'init', []);
          this.font = new me.Font('Arial', 32, '#FFFFFF');
          this.emailInput = new me.Font('input', 100, 100, {
            width: 200,
            height: 30,
            background: '#CCCCCC',
            border: '#000000'
          });
          this.passwordInput = new me.Font('input', 100, 150, {
            width: 200,
            height: 30,
            background: '#CCCCCC',
            border: '#000000'
          });
          var LoginButton = new me.Sprite(100, 200, {
            image: me.loader.getImage('LoginButton'),
            framewidth: 100,
            frameheight: 50
          });
          var SignupButton = new me.Sprite(150, 200, {
            image: me.loader.getImage('SignUpButton'),
            framewidth: 100,
            frameheight: 50
          });
        },

        // Draw the screen
        draw: function(renderer) {
          this.font.draw(renderer, 'Login', 100, 50);
          this.emailInput.draw(renderer);
          this.passwordInput.draw(renderer);
 //         this.loginButton.draw(renderer);
            me.game.world.addChild(LoginButton);
          me.game.world.addChild(SignupButton);
        },


        // Handle mouse events
        pointerdown: function(event) {
          if (this.loginButton.clicked(event)) {
            const email = this.emailInput.value();
            const password = this.passwordInput.value();
            const db = client.db('mydatabase');
            const collection = db.collection('users');
            collection.findOne({ email: email, password: password }, (err, result) => {
              if (err) {
                console.error('Error finding user in database', err);
                return;
              }
              if (result) {
                console.log('User found in database');
              } else {
                console.log('User not found in database');
              }
            });
          }
        }
      });

      // Start the game
      me.game.world.addChild(new LoginScreen());
      me.state.change(me.state.PLAY);
    });
